
-- --------------------------------------------------------

--
-- Структура таблицы `cards`
--

CREATE TABLE `cards` (
  `id` int(11) NOT NULL,
  `code` tinytext NOT NULL,
  `photo` tinytext NOT NULL,
  `lang` varchar(3) NOT NULL,
  `title` tinytext NOT NULL,
  `main_info` text NOT NULL,
  `link` tinytext NOT NULL,
  `list_order` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `cards`
--

INSERT INTO `cards` (`id`, `code`, `photo`, `lang`, `title`, `main_info`, `link`, `list_order`) VALUES
(1, 'lighter_1', 'tovar1.jpg', 'RUS', 'Lighter: Hoodie', 'Линейка - Ucollection Artjom. Продаётся в едином экземпляре. Цена: 45 euro', 'link', 1),
(2, 'lighter_2', 'tovar2.jpg', 'RUS', 'Lighter: Sweatshirt', 'Линейка - Безвкусно и скучно. Продаётся в едином экземпляре. Цена: 30 euro', 'link', 2),
(3, 'lighter_3', 'tovar3.jpg', 'RUS', 'Lighter: Half-Zip', 'Линейка - Basic Сollection. Продаётся в едином экземпляре. Цена: 40 euro', 'link', 3),
(4, 'dormeo_1', 'tovar4.jpg', 'RUS', 'Dormeo: Lux Setup', 'Кровать с современным дизайном. Продаётся без матраса. Тип: двуспальные кровати. Размер: 180х220см. Цена: 500 евро', 'link', 4),
(5, 'dormeo_2', 'tovar5.jpg', 'RUS', 'Dormeo : Classic', 'Матрас- ультра мягкий.\r\nРазмер: 200 x 200 см.\r\nМатериал: полиэтилен.\r\nТип: двуспальный матрас\r\nЦена: 200 euro', 'link', 5),
(6, 'dormeo_3', 'tovar6.jpg', 'RUS', 'Dormeo: Cheap', 'Матрас подешевле.\r\nМатрас - ультра неудобный.\r\nРазмер: 100 x 200 см.\r\nМатериал: органический.\r\nТип: односпальный матрас.\r\nЦена: 199.99 euro', 'link', 6),
(7, 'comp_1', 'tovar7.jpg', 'RUS', 'Apple iMac Pro / MQ2Y2ZE/A / 27\" Retina / Xeon W / 32GB RAM / 1TB', 'Самый дорогой и слабый что есть\r\nЦена:  7000 евро\r\nМатериал: Алюминий обыкновенный\r\nНовейшие революции Johnny.\r\nОперационная система: Windows 95', 'link', 7),
(8, 'comp_2', 'tovar8.jpg', 'RUS', 'In Win Winbot Design Tower White/Blue', 'Корпус - 100 евро. Главное что светится.\r\nРазмер корпуса 	Mid tower (ATX)\r\nМатериал	Алюминий\r\n', 'link', 8),
(9, 'comp_3', 'tovar9.jpg', 'RUS', 'A700 Aluminum Tempered Glass ', 'Машина времени, бюджетный вариант\r\nЦена: 161656498 евро', 'link', 9),
(10, 'lighter_1', 'tovar1.jpg', 'EST', 'Lighter: Hoodie', 'Valitseja - kogumine Artjom. Müüdud lingina. Hind: 45 eurot', 'link', 1),
(11, 'lighter_2', 'tovar2.jpg', 'EST', 'Lighter: Sweatshirt', 'Joonlaud - maitsetu ja igav. Müüakse ühes eksemplaris. Hind: 30 eurot', 'link', 2),
(12, 'lighter_3', 'tovar3.jpg', 'EST', 'Lighter: Half-Zip', 'Линейка - Basic Сollection. Продаётся в едином экземпляре. Цена: 40 euro', 'link', 3),
(13, 'dormeo_1', 'tovar4.jpg', 'EST', 'Dormeo: Lux Setup', 'Moodsa disainiga voodi. Müüakse ilma madratsita. Tüüp: kaheinimesevoodid. Suurus: 180x220cm. Hind: 500 eurot', 'link', 4),
(14, 'dormeo_2', 'tovar5.jpg', 'EST', 'Dormeo : Classic', 'Madrats on ülipehme.\r\nSuurus: 200 x 200 cm.\r\nMaterjal: polüetüleen.\r\nTüüp: topelt madrats\r\nHind: 200 eurot', 'link', 5),
(15, 'dormeo_3', 'tovar6.jpg', 'EST', 'Dormeo: Cheap', 'Madrats on odavam.\r\nMadrats on eriti ebamugav.\r\nMõõdud: 100 x 200 cm.\r\nMaterjal: orgaaniline.\r\nTüüp: ühekordne madrats.\r\nHind: 199,99 eurot', 'link', 6),
(16, 'comp_1', 'tovar7.jpg', 'EST', 'Apple iMac Pro / MQ2Y2ZE/A / 27\" Retina / Xeon W / 32GB RAM / 1TB', 'Seal on kõige kallim ja nõrgem\r\nHind: 7000 eurot\r\nMaterjal: tavaline alumiinium\r\nJohnny uusimad revolutsioonid.\r\nOperatsioonisüsteem: Windows 95', 'link', 7),
(17, 'comp_2', 'tovar8.jpg', 'EST', 'In Win Winbot Design Tower White/Blue', 'Kohver - 100 eurot. Peaasi, et see hõõguks.\r\nKeskmise torni korpuse suurus (ATX)\r\nMaterjal Alumiinium\r\n', 'link', 8),
(18, 'comp_3', 'tovar9.jpg', 'EST', 'A700 Aluminum Tempered Glass ', 'Ajamasin, eelarvevalik\r\nHind: 161656498 euro', 'link', 9),
(19, 'lighter_1', 'tovar1.jpg', 'ENG', 'Lighter: Hoodie', 'Ruler - Ucollection Artjom. Sold in a single copy. Price: 45 euro', 'link', 1),
(20, 'lighter_2', 'tovar2.jpg', 'ENG', 'Lighter: Sweatshirt', 'Ruler - Tasteless and boring. Sold in a single copy. Price: 30 euro', 'link', 2),
(21, 'lighter_3', 'tovar3.jpg', 'ENG', 'Lighter: Half-Zip', 'Ruler - Basic Collection. Sold in a single copy. Price: 40 euro', 'link', 3),
(22, 'dormeo_1', 'tovar4.jpg', 'ENG', 'Dormeo: Lux Setup', 'Bed with modern design. Sold without mattress. Type: double beds. Size: 180x220cm. Price: 500 euros', 'link', 4),
(23, 'dormeo_2', 'tovar5.jpg', 'ENG', 'Dormeo : Classic', 'The mattress is ultra soft.\r\nSize: 200 x 200 cm.\r\nMaterial: polyethylene.\r\nType: double mattress\r\nPrice: 200 euro', 'link', 5),
(24, 'dormeo_3', 'tovar6.jpg', 'ENG', 'Dormeo: Cheap', 'The mattress is cheaper.\r\nThe mattress is ultra uncomfortable.\r\nDimensions: 100 x 200 cm.\r\nMaterial: organic.\r\nType: single mattress.\r\nPrice: 199.99 euro', 'link', 6),
(25, 'comp_1', 'tovar7.jpg', 'ENG', 'Apple iMac Pro / MQ2Y2ZE/A / 27\" Retina / Xeon W / 32GB RAM / 1TB', 'The most expensive and weakest there is\r\nPrice: 7000 euros\r\nMaterial: Ordinary aluminum\r\nJohnny\'s newest revolutions.\r\nOperating system: Windows 95', 'link', 7),
(26, 'comp_2', 'tovar8.jpg', 'ENG', 'In Win Winbot Design Tower White/Blue', 'Case - 100 euros. The main thing is that it glows.\r\nMid tower case size (ATX)\r\nMaterial Aluminum\r\n', 'link', 8),
(28, 'comp_3', 'tovar9.jpg', 'ENG', 'A700 Aluminum Tempered Glass ', 'Time machine, budget option\r\nPrice: 161656498 euro', 'link', 9);

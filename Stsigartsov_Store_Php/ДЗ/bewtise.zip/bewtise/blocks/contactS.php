<section id="contactS" class="section">
<div class="container bgdefault">
<div class="boxx" style="background:white; z-index:1000;height: 400px;">
<pre><h5 id="fat"><?php echo $terms['contact']?></h5>
<h6><?php echo $terms['questionHeader']?></h6>
<?php echo $terms['text1']?>
<h6><?php echo $terms['serviceHeader']?></h6>
<?php echo $terms['text2']?>
<h6><?php echo $terms['detailsHeader']?></h6>
<?php echo $terms['text3']?>
</pre>
</div></div>
</section>
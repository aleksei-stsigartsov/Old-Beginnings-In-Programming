<section id="navnav" class="section">
<div class="container bgdefault">
<div data-spy="scroll" data-target="#navbar-example2" data-offset="0">
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
     <li class="nav-item dropdown active">
	<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <?php echo $terms['storeCatalog']?>
        </a>		
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
		<a><?php echo $terms['chooseCategory']?><span class="sr-only">(current)</span></a>
		<a class="dropdown-item" href="#it"><?php echo $terms['compDep']?></a>
		  <div class="dropdown-divider"></div>
		  <a class="dropdown-item" href="#lighter"><?php echo $terms['storeClothes']?></a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#matras"><?php echo $terms['storeFurniture']?></a>
        </div>
	  <li class="nav-item ">
        <a class="nav-link disabled" href="#"><?php echo $terms['storeNews']?><span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#"><?php echo $terms['storePromotions']?></a> <span class="sr-only">(current)</span></a>
      </li>
	  <li class="nav-item">
        <a class="nav-link disabled" href="#"><?php echo $terms['storeAdvice']?><span class="sr-only">(current)</span></a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" action="http://localhost/bewtise/index.php?ln=EST" placeholder=<?php echo $terms['searchButton']?> aria-label="Search">
      <button class="btn btn-outline-dark my-2 my-sm-0" type="submit" action="http://localhost/bewtise/index.php?ln=EST"><img src="photos/poisk1.jpg" height="25px"></button>
    </form>
  </div>
</nav>
</div>
</div>
</section>
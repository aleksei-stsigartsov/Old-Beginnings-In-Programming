<section id="navnav" class="section">
<div class="col-14">
<nav class="navbar navbar-dark bg-dark">
	<a><img src="photos/kazan.png" height="50px" width="50px" ></a>
  <a class="navbar-brand" href="http://localhost/bewtise/index.php?ln=EST">Stsigartsov Store</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
	  <div class="dropdown-divider"></div>
        <a class="nav-link" href="#fat"><?php echo $terms['ourContacts']?><span class="sr-only">(current)</span></a>
		<div class="dropdown-divider"></div>
      </li>
    </ul>
  </div>
</nav>
</div>
</section>
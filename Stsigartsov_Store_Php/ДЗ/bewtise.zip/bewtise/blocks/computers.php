<section id="computers" class="section">
<div class="container bgdefault">
<h3 class="font1" id="it"><?php echo $terms['technoHeader']?></h3>
<div class="row">
<div>
  <img src="photos/logou4.jpg"   width="275px" class="card" alt="...">
    <img src="photos/logou5.jpg"  height="350px" width="275px" class="card" alt="...">
</div>
<?php
                
                if(empty($_GET['ln'])) {$pageLang='RUS';}
                else {$pageLang=$_GET['ln'];}

                $result = mysqli_query($link, "SELECT * FROM cards WHERE lang='$pageLang' AND list_order>6 ORDER BY list_order");
                while($stroka=mysqli_fetch_assoc($result)){
                    echo '<div class="col-3">
                    <div class="card">
                    <img src="photos/'.$stroka['photo'].'" width="286 px" class="card-img-top" alt="">
                    <div class="card-body">
                    <h5 class="card-title">'.$stroka['title'].'</h5>
                    <p class="card-text">'.$stroka['main_info'].'</p>
					<label class="btn btn-dark active">
					<input type="checkbox" name="options" id="option1" > '.$terms['addCart'].'
					</label>
                    </div>
                    </div>
                    </div>';
                }
                ?>
</div>
</div>
</section>
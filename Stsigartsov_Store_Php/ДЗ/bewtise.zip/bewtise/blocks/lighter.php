<section id="lighter" class="section">
<div class="container bgdefault">
<h2 class="font1"><?php echo $terms['storeSuggestion']?></h2>
</br>
<h3 class="font1" id="lighter"><?php echo $terms['lighterHeader']?></h3>
<div class="row">
<div>
  <img src="photos/logou.jpg" height="566px" width="262px" class="card" alt="...">
</div>

	                <?php
                
                if(empty($_GET['ln'])) {$pageLang='RUS';}
                else {$pageLang=$_GET['ln'];}

                $result = mysqli_query($link, "SELECT * FROM cards WHERE lang='$pageLang' AND list_order<=3 ORDER BY  list_order");
                while($stroka=mysqli_fetch_assoc($result)){
                    echo '<div class="col-3">
                    <div class="card">
                    <img src="photos/'.$stroka['photo'].'" height="358px" width="286 px" class="card-img-top" alt="">
                    <div class="card-body">
                    <h5 class="card-title">'.$stroka['title'].'</h5>
                    <p class="card-text">'.$stroka['main_info'].'</p>
					<label class="btn btn-dark active">
					<input type="checkbox" name="options" id="option1" > '.$terms['addCart'].'
					</label>
                    </div>
                    </div>
                    </div>';
                }
                ?>
</div></div>
</br>
</section>

<?php
require_once "connect.php";

$langTable=mysqli_query($link,"SELECT DISTINCT lang FROM cards");
$langTest=false;
while($oneLang=mysqli_fetch_assoc($langTable)){
	if($_GET['ln']==$oneLang['lang']){$langTest=true;} 
}
if($langTest==false){$_GET['ln']='RUS';}
if(empty($_GET['ln'])){$pageLang='RUS';}else{$pageLang=$_GET['ln'];}

$termsTable=mysqli_query($link, "SELECT * FROM terms WHERE lang='$pageLang'");
$terms=array();
while($oneTerm=mysqli_fetch_assoc($termsTable)){
	$terms[$oneTerm['code']]=$oneTerm['termText'];
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<link rel="shortcut icon" type="image/x-icon" href="photos/favicon.ico">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap" rel="stylesheet">
<title>Stsigartsov Store</title>
<style>
<?php echo file_get_contents("style.css"); ?>
</style>
</head>

<body>
<div class="flyMenu">
<div class="row">
<?php
        $langTable = mysqli_query($link, "SELECT DISTINCT lang FROM cards");
        while($oneLang=mysqli_fetch_assoc($langTable)){
            echo '<li class="nav-item">
            <a class="nav-link font2" href="?ln='.$oneLang['lang'].'">'.$oneLang['lang'].'</a>
        </li>'; 
        }
        ?>
</div></div>
<?php include "blocks/navnav.php"; ?>

<?php include "blocks/navnav2.php"; ?>

<?php include "blocks/caruselj.php"; ?>

<?php include "blocks/lighter.php"; ?>

<?php include "blocks/dormeo.php"; ?>

<?php include "blocks/computers.php"; ?>

<?php include "blocks/contactS.php"; ?>

<?php include "blocks/copyright.php"; ?>


<script src="js/jquery-3.5.1.slim.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/popper.min.js"></script>
</body>

</html>
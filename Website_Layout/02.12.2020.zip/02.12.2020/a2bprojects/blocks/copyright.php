<section id="copyright">
<footer class="page-footer">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 page-footer__copyright">
          <span class="font2">© Copyright 2020 / Aleksei Stsigartsov  TA-19V</span>
        </div>
      </div>
    </div>
 </footer>
</section>
<section id="basement" class="section">

		<div class="boxx2">
		<div class="row">
		
<div class="col-12 col-md-6 col-lg-6"><br>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d852.87313407625!2d24.767090485024028!3d59.441653445837595!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4692935d10a073cf%3A0xd614d8db32d66304!2sUus-Sadama%2019%2F8%2C%2010120%20Tallinn!5e0!3m2!1sru!2see!4v1578586081757!5m2!1sru!2see" width="100%" height="300" frameborder="0" style="border:0;" allowfullscreen=""></iframe></div>
<div class="col-12 col-md-6 col-lg-4">
<h5 class="font2"><?php echo $terms['kontaKT']?></h5>
<pre><p class="font2"><?php echo $terms['inFO']?>
</p></pre>
</div></div>
</section>